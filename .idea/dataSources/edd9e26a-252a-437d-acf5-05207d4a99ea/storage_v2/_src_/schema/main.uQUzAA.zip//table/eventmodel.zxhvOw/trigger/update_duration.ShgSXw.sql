CREATE TRIGGER update_duration AFTER UPDATE ON eventmodel
        WHEN OLD.duration != new.duration
        begin
            update "resource-old"
            set duration = new.duration
            where eventmodel_id = new.id;
        end;

