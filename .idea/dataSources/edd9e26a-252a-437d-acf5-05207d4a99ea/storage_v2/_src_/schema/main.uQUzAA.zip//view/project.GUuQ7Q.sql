CREATE VIEW project as
select timestamp start_timestamp, datetime(timestamp, '+10 minutes') end_timestamp, json_extract(datastr, '$.projectPath') as path
from eventmodel
where json_extract(datastr, '$.projectPath') = (
  select json_extract(datastr, '$.projectPath')
  from eventmodel
  where json_extract(datastr, '$.project') is not null
    and timestamp >= datetime('now', '-10 minutes')
  order by timestamp desc
  limit 1
);

