CREATE TRIGGER add_resource
                after insert on eventmodel
                for each row
                    begin
                    insert into resource (eventmodel_id, timestamp, duration, tracker_name, tracker_type, app_name, app_title, reference, project)
                    values (
                        new.id,
                        new.timestamp,
                        new.duration,
                        (
                          select client
                          from bucketmodel
                          where key = new.bucket_id
                        ),  --  as tracker_name
                        (
                            select type
                            from bucketmodel
                            where key = new.bucket_id
                        ), --  as tracker_type
                        (
                            select
                                case type
                                    when 'app.editor.activity' then NULL
                                    when 'web.tab.current' then NULL
                                    when 'currentwindow' then json_extract(new.datastr, '$.app')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as app_name
                        (
                            select
                                case type
                                    when 'app.editor.activity' then NULL
                                    when 'web.tab.current' then
                                        case bucketmodel.id
                                            when 'aw-watcher-web-firefox' then json_extract(new.datastr, '$.title') || ' - Mozilla Firefox'
                                            when 'aw-watcher-web-chrome' then json_extract(new.datastr, '$.title') || ' - Google Chrome'
                                        end
                                    when 'currentwindow' then json_extract(new.datastr, '$.title')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as app_title
                        (
                            select
                                case type
                                    when 'app.editor.activity' then json_extract(new.datastr, '$.file')
                                    when 'web.tab.current' then json_extract(new.datastr, '$.url')
                                    when 'currentwindow' then json_extract(new.datastr, '$.title')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as reference
                        (
                          select json_extract(datastr, '$.projectPath')
                          from eventmodel
                          where json_extract(datastr, '$.project') is not null
                            and timestamp >= datetime('now', '-10 minutes')
                          order by timestamp desc
                          limit 1
                        ) -- as project
                    );
            end;

