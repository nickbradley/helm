CREATE TRIGGER add_resource
                after insert on eventmodel
                for each row
                    begin
                    insert into resource (eventmodel_id, timestamp, duration, tracker_name, app_name, app_title, reference, project)
                    values (
                        new.id,
                        new.timestamp,
                        new.duration,
                        (
                          select client
                          from bucketmodel
                          where key = new.bucket_id
                        ),  --  as tracker_name
                        (
                            select
                                case client
                                    when 'aw-watcher-idea' then NULL
                                    when 'aw-client-web' then NULL
                                    when 'aw-watcher-window' then json_extract(new.datastr, '$.app')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as app_name
                        (
                            select
                                case client
                                    when 'aw-watcher-idea' then NULL
                                    when 'aw-client-web' then
                                        case bucketmodel.id
                                            when 'aw-watcher-web-firefox' then json_extract(new.datastr, '$.title') || ' - Mozilla Firefox'
                                        end
                                    when 'aw-watcher-window' then json_extract(new.datastr, '$.title')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as app_title
                        (
                            select
                                case client
                                    when 'aw-watcher-idea' then json_extract(new.datastr, '$.file')
                                    when 'aw-client-web' then json_extract(new.datastr, '$.url')
                                    when 'aw-watcher-window' then json_extract(new.datastr, '$.title')
                                end
                            from bucketmodel
                            where key = new.bucket_id
                        ),  --  as reference
                        (
                          select json_extract(datastr, '$.projectPath')
                          from eventmodel
                          where json_extract(datastr, '$.project') is not null
                            and timestamp >= datetime('now', '-10 minutes')
                          order by timestamp desc
                          limit 1
                        ) -- as project
                    );
            end;

